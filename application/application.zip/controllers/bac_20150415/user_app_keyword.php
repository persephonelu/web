<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//用户app管理页面
class User_app_keyword extends CI_Controller {
    //获得关键词列表,restful
    public function get_user_keywords()
    {
        
    } 

}
